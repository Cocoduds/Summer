#include "TFTDisplay.h"

Adafruit_ST7789 TFTDisplay::tft = Adafruit_ST7789(_TFT_CS, _TFT_DC, _TFT_RST);

TFTDisplay::pulseDisplay::pulseDisplay(const int& x, const int& y, const uint16_t& background) {
  this->eraseColor = background;
  this->x = x;
  this->y = y;
}

TFTDisplay::spectTextDisplay::spectTextDisplay(const int& x, const int& y, const uint16_t& background) {
  this->eraseColor = background;
  this->x = x;
  this->y = y;
}

void TFTDisplay::pulseDisplay::display(const uint16_t& BPM, const uint16_t& oxygen, const uint8_t& conf) {
  this->eraseOld();
  tft.setCursor(x, y);
  
  tft.setTextColor(_TEXT_COLOR);
  tft.print(_BPM_label);
  tft.print(BPM);
  tft.println();
  

  tft.setCursor(x, tft.getCursorY());
  tft.print(_CONF_label);
  tft.print(conf);
  tft.println();


  tft.setCursor(x, tft.getCursorY());
  tft.print(_OXY_label);
  tft.print(oxygen);
  tft.println();

  oldVals.heartRate = BPM;
  oldVals.oxygen = oxygen;
  oldVals.conf = conf;
}

void TFTDisplay::pulseDisplay::eraseOld() {
  tft.setCursor(x, y);

  tft.setTextColor(_TEXT_COLOR);
  tft.print(_BPM_label);
  tft.setTextColor(eraseColor);
  tft.print(oldVals.heartRate);
  tft.println();
  tft.setCursor(x, tft.getCursorY());
  
  tft.setTextColor(_TEXT_COLOR);
  tft.print(_CONF_label);
  tft.setTextColor(eraseColor);
  tft.print(oldVals.conf);
  tft.println();
  tft.setCursor(x, tft.getCursorY());

  tft.setTextColor(_TEXT_COLOR);
  tft.print(_OXY_label);
  tft.setTextColor(eraseColor);
  tft.print(oldVals.oxygen);
  tft.println();
  tft.setCursor(x, tft.getCursorY());
}

void TFTDisplay::setup(void) {
  pinMode(_TFT_MOSI, INPUT);
  pinMode(_TFT_SCLK, INPUT);
  tft.init(240, 240);
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextWrap(false);
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(2);
}

void TFTDisplay::summary(int BPM, int CNF, int SpO2) {
  tft.setTextWrap(false);
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextColor(ST77XX_RED);
  tft.setTextSize(3);

  tft.setCursor(100, 50);
  tft.print(BPM);tft.println(" BPM");
  tft.setCursor(100, 100);
  tft.print(CNF);tft.println(" %");
  tft.setCursor(100, 150);
  tft.print(SpO2);tft.println(" %");
}

void TFTDisplay::FullSummary(const int& BPM, const int& CNF, const int& SpO2, const int& IR_LED, const int& R_LED, 
                              const int& status, const int& BLUE, const int& RED, const int& GREEN, const int& ORANGE, const int& PURPLE) {
  tft.setCursor(100, 50);
  tft.print(BPM);tft.println(" BPM");
  tft.setCursor(100, 75);
  tft.print(CNF);tft.println(" CONF (%)");
  tft.setCursor(100, 100);
  tft.print(SpO2);tft.println(" SpO2 (%)");
  tft.setCursor(100, 125);
  tft.println(IR_LED, R_LED);
  tft.setCursor(10, 150);
  tft.print("Status: ");tft.println(status);
  tft.setCursor(0, 175);

  //Printing the sprectrum
  tft.print(BLUE); tft.print(" ");
  tft.print(RED); tft.print(" ");
  tft.print(GREEN); tft.print(" ");
  tft.print(ORANGE); tft.print(" ");
  tft.print(PURPLE); tft.print(" ");
};

void TFTDisplay::spectTextDisplay::display(const float& spo2, const float betas[5], const uint16_t channelCounts[6]) {
    this->eraseOld();
    tft.setCursor(x, y);
    tft.setTextColor(_TEXT_COLOR);
    tft.print(_SPO2_label);
    tft.print(spo2, 2);

    this->maxX = 0;
    if (maxX < tft.getCursorX()) {
        this->maxX = tft.getCursorX();
    }

    tft.println();
    tft.setCursor(x, tft.getCursorY());
    
    for (int i = 0; i < 5; i++) {
      tft.print(_BETA_label(i + 1));
      tft.print(betas[i], 2);

      if (maxX < tft.getCursorX()) {
        this->maxX = tft.getCursorX();
      }

      tft.println();
      tft.setCursor(x, tft.getCursorY());
    }

    this->maxX += 8;

    tft.setCursor(this->maxX, y);
    for (int i = 0; i < 6; i++) {
      tft.print(_CHANNEL_label(i + 1));
      tft.print(channelCounts[i]);
      tft.println();
      tft.setCursor(this->maxX, tft.getCursorY());
    }

    oldVals.oxygen = spo2;
    for (int i = 0; i < 5; i++) {
      oldVals.betas[i] = betas[i];
      oldVals.channel[i] = channelCounts[i];
    }
    oldVals.channel[5] = channelCounts[5];
};


void TFTDisplay::spectTextDisplay::eraseOld() {
  tft.setCursor(x, y);
  tft.setTextColor(_TEXT_COLOR);
  tft.print(_SPO2_label);
  tft.setTextColor(eraseColor);
  tft.print(oldVals.oxygen, 2);
  tft.println();
  tft.setCursor(x, tft.getCursorY());

  for (int i = 0; i < 5; i++) {
    tft.setTextColor(_TEXT_COLOR);
    tft.print(_BETA_label(i + 1));
    tft.setTextColor(eraseColor);
    tft.print(oldVals.betas[i], 2);
    tft.println();
    tft.setCursor(x, tft.getCursorY());
  }

  if (maxX == 0) { return; }

  tft.setCursor(this->maxX, y);
  tft.setTextColor(eraseColor);
  for (int i = 0; i < 6; i++) {
    // tft.setTextColor(_TEXT_COLOR);
    tft.print(_CHANNEL_label(i + 1));
    tft.print(oldVals.channel[i]);
    tft.println();
    tft.setCursor(this->maxX, tft.getCursorY());
  }
};
//Todo: The body of the spectTextDisplay need to be written.