#pragma once
#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ST7789.h> // Hardware-specific library for ST7789
#include <SPI.h>
#include "measures.h"
// #include "C:\Users\jackr\Documents\PulseOx_Git\Pulse-Ox\main\src\Measures\measures.h"

#define _TFT_CS 10
#define _TFT_RST 9
#define _TFT_DC 12
#define _TFT_MOSI 11
#define _TFT_SCLK 13

#define _BPM_label "BPM: "
#define _CONF_label "CONF: "
#define _OXY_label "OXY: "

#define _SPO2_label "O2: "
#define _BETA_label(X) "B" + String(X) + ": "
#define _CHANNEL_label(X) "C" + String(X) + ": "


#define _TEXT_COLOR ST77XX_RED

namespace TFTDisplay {
  extern Adafruit_ST7789 tft;

  struct pulseDisplay {
    pulseDisplay(const int& x, const int& y, const uint16_t& background);

    void display(const uint16_t& BPM, const uint16_t& oxygen, const uint8_t& conf);

    private:
    int x, y;
    uint16_t eraseColor;
    struct {
      uint16_t heartRate = 0;
      uint16_t oxygen = 0;
      uint8_t conf = 0;
    } oldVals;

    void eraseOld();
  };

  template<int mCount, int mSize>
  struct spectGraphDisplay {
    Measures::measure<uint16_t, mCount> (*measures)[mSize];
    uint16_t colors[mSize];
    uint16_t backgroundColor;
    uint16_t x, y, w, h;
    const uint16_t ymin = 100;
    const uint16_t ymax = 200;

    spectGraphDisplay(const uint16_t &x, const uint16_t &y, const uint16_t &w, const uint16_t &h,
    const uint16_t &background, const uint16_t *colors,
    Measures::measure<uint16_t, mCount> (*measures)[mSize]) {
      this->backgroundColor = background;
      this->x = x;
      this->y = y;
      this->h = h;
      this->w = w;
      this->measures = measures;

      for (int i = 0; i < mSize; i++) {
          this->colors[i] = colors[i];
          (*measures)[i].setData(y+h);
      }
    }

    void display() {
      const auto binWidth = this -> w / mCount;
      this -> eraseOld();

      tft.drawFastVLine(x, y+h, -h, ST77XX_YELLOW);
      tft.drawFastHLine(x, y+h, w, ST77XX_YELLOW);

      for (int i = 0; i < mSize; i++) {
          for (int idx = 0; idx < mCount; idx++) {
              tft.drawLine(x + idx * binWidth, 
                (*measures)[i].getItem(idx), 
                x + (idx + 1) * binWidth, 
                (*measures)[i].getItem(idx + 1), colors[i]);
          }
      }
    }

    void eraseOld() {
      tft.fillRect(x, y, w+1, h, backgroundColor);
    }

    void addData(uint16_t *dataBuffer) {
      for (int i = 0; i < mSize; i++) {
        uint16_t clamped = (dataBuffer[i] > h) ? y - 1 : y + dataBuffer[i];
        (*measures)[i].addItem(clamped);
      }
    }
  };

  //Todo: This needs to be modified to work with the BaseSPO2Algo class and how it stores information.
  // This will require a near rewrite of how this works but it can be used as an initial base.
  // In general this will need to be able to display the calculated SpO2, calculated betas, and specific channel counts
  struct spectTextDisplay {
    // BaseSPO2Algo* algo; // Pointer to an instance of BaseSPO2Algo to access its data)
    spectTextDisplay(const int& x, const int& y, const uint16_t& background);

    // void display(const uint16_t& BPM, const uint16_t& oxygen, const uint8_t& conf);
    void display(const float& spo2, const float betas[5], const uint16_t channelCount[6]);
   
    private:
    int x, y;
    uint16_t maxX = 0;
    uint16_t eraseColor;
    struct {
      float oxygen = 0;
      float betas[5] = {};
      uint16_t channel[6] = {};
    } oldVals;

    void eraseOld();
  };

  void setup();
  void summary(int BPM, int CNF, int SpO2);
  void FullSummary(const int& BPM, const int& CNF, const int& SpO2, const int& IR_LED, const int& R_LED, const int& status, 
                    const int& BLUE, const int& RED, const int& GREEN, const int& ORANGE, const int& PURPLE);
}