#pragma once
#include "Arduino.h"

#define __KEEP_TIME

namespace Measures {
    struct extremas {
        using extType = uint16_t; //Now things are computed just using this single type right here
        extType high;
        extType low;
    };

    //Computing the size of the array in spectExtremas in case we change the typing of extremas
    // constexpr int __spectSize = 6 * sizeof(extremas) / sizeof(uint16_t);

    struct spectExtremas {
        #ifdef __KEEP_TIME
        int hIdx;
        int lIdx;
        #endif
        union {
            extremas::extType readings[6 * sizeof(extremas) / sizeof(extremas::extType)];
            struct {
                extremas ADC_1;
                extremas ADC_2;
                extremas ADC_3;
                extremas ADC_4;
                extremas ADC_5;
                extremas ADC_6;
            };
        };
    };

    /*
    A ring buffer class that stores count number of types in an array
    When the limit of the array is reached the last added object is 
    removed.
    */
    template<typename T, int count>
    struct measure {
        T m[count] = {};
        int lastIdx = 0;
        static const int Size = count;

        bool addItem(const T &a) {
            // lastIdx = lastIdx % Size;

            m[lastIdx] = T(a);
            // lastIdx++;
            lastIdx = (lastIdx + 1) % Size;
            return true;
        }

        bool setData(const T &a) {
            for(int i = 0; i < Size; i++) {
                m[i] = a;
            }
            return true;
        }

        int size() { return Size; }

        /**
         * @brief Get an element from the buffer at the idx index 
         *  starting from the last added element
         * 
         * @param idx The index you would like to get back. Has a 
         *  range of 0 to Size - 1.
         * @return T The element you want from the ring buffer
         */
        T getItem(const int &idx) {
            int modIdx = (Size + lastIdx - ((idx + 1) % Size)) % Size;

            return m[modIdx];
        }

        /**
         * @brief Get an element from the buffer at the idx index
         *  starting from the oldest available element
         * 
         * @param idx The index you would like to get back. Has a
         *  range of 0 to Size - 1.
         * @return T The element you want from the ring buffer
         */
        T getItemRev(const int &idx) {
            int modIdx = (lastIdx + idx) % Size;

            return m[modIdx];
        }
    };

    template<typename T, int count>
    struct runningMeasure: protected measure<T, count> {
        float runningSum = 0;

        bool addItem(const T &a) {
            this->lastIdx = this->lastIdx % this->Size;
            runningSum += a - this->m[this->lastIdx];

            this->m[this->lastIdx] = a;
            this->lastIdx++;
            return true;
        }

        float std() {
            float avg = runningSum / this->Size;
            float sum = 0;
            for (int i = 0; i < this->Size; i++) {
                sum += pow(this->getItem(i) - avg, 2.0);
            }

            return sqrt(sum / (this->Size - 1));
        }

        float lastZScore() {
            float avg = runningSum / this->Size;
            return (this->getItem(0) - avg) / std();
        }
    };

    template<class T, int mCount, int mSize>
    class BaseSPO2Algo {
        protected:
        Measures::runningMeasure<uint16_t, 60> running = {};
        Measures::measure<spectExtremas, 10> peaks = {};
        uint8_t currentPeakCount = 0;
        const static float M_algoConsts[5];
        const static float N_algoConsts[5];
        const static float N0_algoConsts;

        public:
        spectExtremas getExtreme(int idx) { return peaks.getItem(idx); }

        template<class input>
        uint8_t update(input measures[mSize], int start, int end) {
            this->currentPeakCount = static_cast<T*>(this)->implementation(measures, start, end);

            return this->currentPeakCount;
        }

        bool calcBeta(uint8_t idx, float betas[5]) {
            if (idx >= this->currentPeakCount) { return false; }
            Measures::spectExtremas peak = peaks.getItem(idx);

            const float den = (peak.ADC_6.high - peak.ADC_6.low) / float(peak.ADC_6.low);

            for (uint8_t i = 0; i < 5; i++) {
                Serial.print(peak.readings[2*i]); Serial.print(",");
                Serial.print(peak.readings[2*i + 1]); Serial.print(",");
                betas[i] = (peak.readings[2*i] - peak.readings[2*i + 1]) / (den * peak.readings[2*i + 1]);
            }
            Serial.println();
            return true;
        }
        
        float calcSO2(float betas[5]) {
            //Asuume that if betas is an array of size n, 
            //then consts is an array of size 2n+1
            //float M_consts

            float S_O2 = 
                (1 - M_algoConsts[0]*betas[0] - M_algoConsts[1]*betas[1] - M_algoConsts[2]*betas[2] - M_algoConsts[3]*betas[3] - M_algoConsts[4]*betas[4])/
                (N0_algoConsts - N_algoConsts[0]*betas[0] - N_algoConsts[1]*betas[1] - N_algoConsts[2]*betas[2] - N_algoConsts[3]*betas[3] - N_algoConsts[4]*betas[4]);


            return S_O2;
        };
    };

    template<int mCount, int mSize>
    class ZScore: public BaseSPO2Algo<ZScore<mCount, mSize>, mCount, mSize> {
        using parentType = BaseSPO2Algo<ZScore<mCount, mSize>, mCount, mSize>;
        const static float threshold; //Since this is a float it is initialized in a definition

        public:
        uint8_t implementation(Measures::measure<uint16_t, mCount> measures[mSize], int start, int end) {
            uint8_t count = 0;

            spectExtremas tempExtrema = {};
            bool validHigh = false;
            bool validLow = false;

            for (int i = end; i>start; i--) {
                uint16_t sum = 0;
                for (int j = 0; j < mSize; j++) {
                    sum += measures[j].getItem(i);
                }
                parentType::running.addItem(sum);

                //Todo: We need to calculate both high's and low's
                //Todo: We need to only keep track of alternating high's then lows

                // Serial.print(parentType::running.lastZScore()); Serial.print(",");
                if (parentType::running.lastZScore() > threshold) {
                    #ifdef __KEEP_TIME
                    tempExtrema.hIdx = int(i);
                    #endif
                  for (int x = 0; x < mSize; x++) {
                    tempExtrema.readings[2*x] = measures[x].getItem(i); //Even indexes are highs
                  }
                  validHigh = true;
                } else if (parentType::running.lastZScore() < -threshold) {
                    #ifdef __KEEP_TIME
                    tempExtrema.lIdx = int(i);
                    #endif
                    for (int x = 0; x < mSize; x++) {
                        tempExtrema.readings[2*x+1] = measures[x].getItem(i); //Odd indexes are lows
                    }
                    validLow = true;
                }

                if (validHigh && validLow) {
                      parentType::peaks.addItem(tempExtrema);
                      validHigh = false;
                      validLow = false;
                    count += 1;
                }

                if (count >= 10) {
                    break;
                }
            }
            return count;
        };

        //Todo: The above function needs to be implemented with this signature (shouldn't take long)
        void implementation(uint16_t measures[mCount][mSize], int start, int end) {
            int count = 0;

            // auto derefMeasures = *measures;
            for (int i = end; i>start; i--) {
                uint16_t sum = 0;
                for (int j = 0; j < mSize; j++) {
                    sum += measures[j][i];
                }
                parentType::running.addItem(sum);

                if (parentType::running.std() > 1) {
                    parentType::peaks.addItem({sum, sum-10});
                    count += 1;
                }

                if (count >= 10) {
                    break;
                }
            }
        };
    };

    //Used to define the static constant floats inside of BaseSpO2Algo
    template<class T, int mCount, int mSize>
    const float BaseSPO2Algo<T, mCount, mSize>::M_algoConsts[5] = {
            -14.977482,
        	7.634920,
            -3.614896,
            0.951455,
            3.954899
        };

    template<class T, int mCount, int mSize>
    const float BaseSPO2Algo<T, mCount, mSize>::N_algoConsts[5] = {
        -23.595131,
        13.990142,
        -1.578475,
        0.806263,
        1.952930
    };

    template<class T, int mCount, int mSize>
    const float BaseSPO2Algo<T, mCount, mSize>::N0_algoConsts = 0.939145;


    //Used to define a static constant float inside of ZScore
    template<int mCount, int mSize>
    const float ZScore<mCount, mSize>::threshold = 1.75f;
}