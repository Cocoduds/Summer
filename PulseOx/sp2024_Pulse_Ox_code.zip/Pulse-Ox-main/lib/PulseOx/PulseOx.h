#pragma once
#include <Arduino.h>
#include <SparkFun_Bio_Sensor_Hub_Library.h>
#include <Wire.h>

#define PULSE_OX_HEADER "BPM,CNF,O2,STATUS"

namespace PulseOx {
    const int resPin = 5;
    const int mfioPin = 6;

    float calcR(const float &redCounts, const float &irCounts);

    // Takes address, reset pin, and MFIO pin.
    extern SparkFun_Bio_Sensor_Hub bioHub; 

    extern bioData body;  
    // ^^^^^^^^^
    // What's this!? This is a type (like int, byte, long) unique to the SparkFun
    // Pulse Oximeter and Heart Rate Monitor. Unlike those other types it holds
    // specific information on your heartrate and blood oxygen levels. BioData is
    // actually a specific kind of type, known as a "struct". 
    // You can choose another variable name other than "body", like "blood", or
    // "readings", but I chose "body". Using this "body" varible in the 
    // following way gives us access to the following data: 
    // body.heartrate  - Heartrate
    // body.confidence - Confidence in the heartrate value
    // body.oxygen     - Blood oxygen level
    // body.status     - Has a finger been sensed?

    void setup();

    struct pulseMeasures: public Printable, bioData {
      // pulseMeasures(const bioData &x) : bioData(x) {}

      size_t printTo(Print& p) const;
    };

    pulseMeasures data();
}