#include "PulseOx.h"

SparkFun_Bio_Sensor_Hub PulseOx::bioHub(PulseOx::resPin, PulseOx::mfioPin);

bioData PulseOx::body;

size_t PulseOx::pulseMeasures::printTo(Print& p) const {
  size_t outBytes = 0;
  outBytes += p.print(heartRate); outBytes += p.print(",");
  outBytes += p.print(confidence); outBytes += p.print(",");
  outBytes += p.print(oxygen); outBytes += p.print(",");
  // outBytes += p.print(irLed); outBytes += p.print(",");
  // outBytes += p.print(redLed); outBytes += p.print(",");
  outBytes += p.print(status);
  return outBytes;
}

float PulseOx::calcR(const float &redCounts, const float &irCounts) {
  return redCounts + irCounts;
}

void PulseOx::setup(void) {
  if (SERCOM_I2CM_CTRLA_ENABLE== 0) {  //Checking if the I2C master is enabled
    Wire.begin();
  }
  int result = bioHub.begin();
  if (result == 0) // Zero errors!
    Serial.println("Sensor started!");
  else
    Serial.println("Could not communicate with the sensor!");
 
  Serial.println("Configuring Sensor...."); 
  int error = bioHub.configBpm(MODE_TWO); // Configuring just the BPM settings. 
  if(error == 0){ // Zero errors!
    Serial.println("Sensor configured.");
  }
  else {
    Serial.println("Error configuring PulseOx sensor.");
    Serial.print("Error: "); 
    Serial.println(error, HEX); 
  }

  // Data lags a bit behind the sensor, if you're finger is on the sensor when
  // it's being configured this delay will give some time for the data to catch
  // up. 
  // Serial.println("Loading up the buffer with data....");
}

struct PulseOx::pulseMeasures PulseOx::data() {

  body = bioHub.readBpm();

  return static_cast<PulseOx::pulseMeasures&>(body);
}