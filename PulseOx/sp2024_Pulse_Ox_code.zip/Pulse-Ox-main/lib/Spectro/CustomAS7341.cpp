#include "Spectro.h"

namespace Spectro {
    bool Custom_AS7341::begin(uint8_t i2c_addr, TwoWire *wire, int32_t sensor_id) {
        if (i2c_dev) {
            delete i2c_dev; // remove old interface
        }

        i2c_dev = new Adafruit_I2CDevice(i2c_addr, wire);

        if (!i2c_dev->begin()) {
            return false;
        }

        if (!_init(sensor_id)) {
            return false;
        }

        return customSMUXSetup();
    }

    bool Custom_AS7341::readAllChannels(void) {
        return readAllChannels(_channel_readings);
    }

    bool Custom_AS7341::readAllChannels(uint16_t *readings_buffer) {
        enableSpectralMeasurement(true); //Start integration
        delayForData(0);

        Adafruit_BusIO_Register channel_data_reg =
            Adafruit_BusIO_Register(i2c_dev, AS7341_CH0_DATA_L, 2);

        return channel_data_reg.read((uint8_t *) readings_buffer, 12);
    }

    //Protected members
    bool Custom_AS7341::customSMUXSetup(void) {
        enableSpectralMeasurement(false);
        setSMUXCommand(AS7341_SMUX_CMD_WRITE);
        //Sending SMUX commands
        // SMUX Config for F8, F7, F6, F5, F4, NIR
        writeRegister(byte(0x00), byte(0x00));
        writeRegister(byte(0x01), byte(0x00));
        writeRegister(byte(0x03), byte(0x10));
        writeRegister(byte(0x04), byte(0x03));
        writeRegister(byte(0x05), byte(0x50));
        writeRegister(byte(0x06), byte(0x40));
        writeRegister(byte(0x07), byte(0x02));
        writeRegister(byte(0x08), byte(0x00));
        writeRegister(byte(0x09), byte(0x40));
        writeRegister(byte(0x0A), byte(0x02));
        writeRegister(byte(0x0C), byte(0x00));
        writeRegister(byte(0x0D), byte(0x05));
        writeRegister(byte(0x0E), byte(0x31));
        writeRegister(byte(0x0F), byte(0x00));
        writeRegister(byte(0x10), byte(0x00));
        writeRegister(byte(0x11), byte(0x00));
        writeRegister(byte(0x13), byte(0x06));

        return enableSMUX();
    }

    bool Custom_AS7341::enableSMUX(void) {
        Adafruit_BusIO_Register enable_reg =
            Adafruit_BusIO_Register(i2c_dev, AS7341_ENABLE);
        Adafruit_BusIO_RegisterBits smux_enable_bit =
            Adafruit_BusIO_RegisterBits(&enable_reg, 1, 4);
        bool success = smux_enable_bit.write(true);

        int timeOut = 1000; // Arbitrary value, but if it takes 1000 milliseconds then
                            // something is wrong
        int count = 0;
        while (smux_enable_bit.read() && count < timeOut) {
            delay(1);
            count++;
        }
        if (count >= timeOut)
            return false;
        else
            return success;
    }

    bool Custom_AS7341::setSMUXCommand(as7341_smux_cmd_t command) {
        Adafruit_BusIO_Register cfg6_reg =
            Adafruit_BusIO_Register(i2c_dev, AS7341_CFG6);
        Adafruit_BusIO_RegisterBits smux_command_bits =
            Adafruit_BusIO_RegisterBits(&cfg6_reg, 2, 3);

        return smux_command_bits.write(command);
    }

    void Custom_AS7341::writeRegister(byte addr, byte val) {
        Adafruit_BusIO_Register reg = Adafruit_BusIO_Register(i2c_dev, addr);
        reg.write(val);
    }
}