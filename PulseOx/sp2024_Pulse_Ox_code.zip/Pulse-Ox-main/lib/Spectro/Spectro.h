#pragma once
#include <Adafruit_AS7341.h>
#include <SPI.h>

#define WAVE_COUNTS_HEADER "ADC1,ADC2,ADC3,ADC4,ADC5,ADC6"

namespace Spectro {

    struct waveCounts: public Printable {
        union
        {
            uint16_t readings[6];
            struct {
                uint16_t ADC_1;
                uint16_t ADC_2;
                uint16_t ADC_3;
                uint16_t ADC_4;
                uint16_t ADC_5;
                uint16_t ADC_6;
            };
        };
        
        size_t printTo(Print& p) const;
    };

    class Custom_AS7341: public Adafruit_AS7341 {
        public:
            bool begin(uint8_t i2c_addr = AS7341_I2CADDR_DEFAULT, TwoWire *wire = &Wire,
             int32_t sensor_id = 0);
            bool readAllChannels(void);
            bool readAllChannels(uint16_t *readings_buffer);

        protected:
            bool customSMUXSetup(void);
            bool enableSMUX(void);
            bool setSMUXCommand(as7341_smux_cmd_t command);
            void writeRegister(byte addr, byte val);
            uint16_t _channel_readings[12];
    };

    extern Custom_AS7341 as7341;

    void setup();

    waveCounts data();
    void data(waveCounts& store);
}