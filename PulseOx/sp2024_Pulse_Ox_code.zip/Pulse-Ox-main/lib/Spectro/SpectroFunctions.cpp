/* This example will use the Arduino plotter to display a select number of wavelengths */

#include "Spectro.h"

Spectro::Custom_AS7341 Spectro::as7341;

void Spectro::setup() {
  if (!Spectro::as7341.begin()){
    Serial.println("Could not find AS7341. Check wiring");
    while (1) { delay(10); }
  }
  Spectro::as7341.enableLED(true);
  Spectro::as7341.setATIME(50);
  Spectro::as7341.setASTEP(50);
  Spectro::as7341.setGain(AS7341_GAIN_256X);
}

Spectro::waveCounts Spectro::data() {
  waveCounts result = {};
  as7341.readAllChannels(result.readings);

  return result;
}

void Spectro::data(Spectro::waveCounts& store) {
  as7341.readAllChannels(store.readings);
}

size_t Spectro::waveCounts::printTo(Print &p) const {
  size_t outSize = 0;
  constexpr int arrSize = sizeof(readings) / sizeof(uint16_t);
  for (int i = 0; i < arrSize - 1; i++) {
    outSize += p.print(readings[i]);
    outSize += p.print(",");
  }
  outSize += p.print(readings[arrSize - 1]);
  return outSize;
}