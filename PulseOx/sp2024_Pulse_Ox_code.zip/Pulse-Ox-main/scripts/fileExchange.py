import configparser
import argparse
import os, shutil
import platform

def main(args: argparse.Namespace):
    config = configparser.ConfigParser()
    config.read(args.cfgPath)

    for fname in config['data']['outFileNames'].split(','):
        fpath = os.path.join(config['SD-Card']['cardLoc'], fname)

        epath = os.path.join(config['data']['dataDir'], f"{args.prefix}_{fname}")
        shutil.copyfile(fpath, epath, follow_symlinks=True)

if __name__ == "__main__":

    parser = argparse.ArgumentParser()

    parser.add_argument("prefix", help="The prefix to be applied to the found files")
    parser.add_argument("--cfgPath", default="./scripts/config.cfg", help="The path to the config file for the script")

    args = parser.parse_args()

    main(args)