#include <unity.h>
#include <Arduino.h>
#include "measures.h"

Measures::measure<uint16_t, 20> measure;
const uint16_t TEST_VAL = 2;

void setUp(void) {
    measure.setData(0);
};

void tearDown(void) {
    measure.setData(0);
}

void test_Add_Data(void) {
    measure.addItem(TEST_VAL);

    TEST_ASSERT_EQUAL_INT16(TEST_VAL, measure.m[0]);
    TEST_ASSERT_EQUAL_INT16(TEST_VAL, measure.getItem(0));

    for (int i = 0; i < measure.Size; i++) {
        measure.addItem(i);
    }

    for (int i = 0; i < measure.Size; i++) {
        TEST_ASSERT_EQUAL_INT16(19 - i, measure.getItem(i));
        TEST_ASSERT_EQUAL_INT16(i, measure.getItemRev(i));
    }
}

void setup() {
    delay(2000); //Waiting to connect
    UNITY_BEGIN();

    RUN_TEST(test_Add_Data);

    UNITY_END();
};

void loop() {};