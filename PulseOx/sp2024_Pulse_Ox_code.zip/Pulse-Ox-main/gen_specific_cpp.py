import os
import shutil
import atexit
from typing import List

Import("env")

def createCPP(file: str):
    newFname = file.replace(".ino", ".cpp")
    shutil.copyfile(file, newFname)
    return newFname

def _delete_lnk(path: str):
    try:
        if os.path.isfile(path):
            os.remove(path)
    except:  # pylint: disable=bare-except
        pass

Fname = os.path.join("./lib/", env['PIOENV'], f"{env['PIOENV']}.ino")
Fname = createCPP(Fname)
atexit.register(_delete_lnk, Fname)