import numpy as np
import pandas as pd
from pOx.adapters import _TIME_COLS
from scipy.signal import argrelextrema

from abc import ABC, abstractmethod, abstractproperty
from typing import Union, List

class peakFinder(ABC):
    @abstractmethod
    def addData(self, newValue: Union[float, int]) -> bool:
        """This adds data into the peak finding method and updates any internal structures to see if it's a peak or not

        Args:
            newValue (Union[float, int]): The value to find the peak of

        Returns:
            bool: If the data was added to the peakFinder correctly
        """
        raise NotImplementedError
    
    @property
    @abstractmethod
    def signals(self) -> np.ndarray:
        """This is an array representing if a specific data point is a peak value or not

        Returns:
            np.ndarray: The mask array if the specific data point is a peak or not
        """
        raise NotImplementedError
    
    @property
    @abstractmethod
    def peakData(self) -> np.ndarray:
        """The filtered data given to the peak finder. Filtered using the signals array

        Returns:
            np.ndarray: The filtered data
        """
        raise NotImplementedError
    
    @abstractmethod
    def __get__(self, idx: int) -> Union[float, int]:
        raise NotImplementedError
    
    @abstractmethod
    def __len__(self) -> int:
        raise NotImplementedError
    
    @abstractmethod
    def clear(self):
        raise NotImplementedError

class windowPeaks(peakFinder):
    def __init__(self, lag: int, threshold: float) -> None:
        assert lag > 0
        assert threshold > 0
        
        self.data = []
        self.lag: int = lag
        self.threshold: float = threshold
        self._signals = [0] * (self.lag) #If a data point is a signal or not
        self._avgs = [0] * (self.lag - 1)
        self._stds = [0] * (self.lag - 1)

    def addData(self, newValue: float | int):
        self.data.append(newValue)

        if len(self) < self.lag:
            return True
        elif len(self) == self.lag:
            self._avgs.append(np.mean(self.data[-self.lag:]))
            self._stds.append(np.std(self.data[-self.lag:]))
            return
        else:
            self._avgs.append(np.mean(self.data[-self.lag:]))
            self._stds.append(np.std(self.data[-self.lag:]))

        if abs(self.data[-1] - self._avgs[-2]) > (self.threshold * self._stds[-2]):
            if self.data[-1] > self._avgs[-2]:
                self._signals.append(1)
            else:
                self._signals.append(-1)
        else:
            self._signals.append(0)

        return
    
    @property
    def signals(self) -> np.ndarray:
        return np.array(self._signals)
    
    @property
    def peakData(self) -> np.ndarray:
        data = np.array(self.data)
        return data[self.signals != 0]

    def __len__(self) -> int:
        return len(self.data)
    
    def __get__(self, idx: int) -> int:
        return self.data[idx]
    
    def clear(self):
        self.data = []
        self._signals = [0] * (self.lag) #If a data point is a signal or not
        self._avgs = [0] * (self.lag - 1)
        self._stds = [0] * (self.lag - 1)
        

class real_time_peak_detection:
    def __init__(self, array, lag, threshold, influence):
        self.y = list(array)
        self.length = len(self.y)
        self.lag = lag
        self.threshold = threshold
        self.influence = influence
        self.signals = [0] * len(self.y)
        self.filteredY = np.array(self.y).tolist()
        self.avgFilter = [0] * len(self.y)
        self.stdFilter = [0] * len(self.y)
        self.avgFilter[self.lag - 1] = np.mean(self.y[0:self.lag]).tolist()
        self.stdFilter[self.lag - 1] = np.std(self.y[0:self.lag]).tolist()

    def thresholding_algo(self, new_value):
        self.y.append(new_value)
        i = len(self.y) - 1
        self.length = len(self.y)
        if i < self.lag:
            return 0
        elif i == self.lag:
            self.signals = [0] * len(self.y)
            self.filteredY = np.array(self.y).tolist()
            self.avgFilter = [0] * len(self.y)
            self.stdFilter = [0] * len(self.y)
            self.avgFilter[self.lag] = np.mean(self.y[0:self.lag]).tolist()
            self.stdFilter[self.lag] = np.std(self.y[0:self.lag]).tolist()
            return 0

        self.signals += [0]
        self.filteredY += [0]
        self.avgFilter += [0]
        self.stdFilter += [0]

        if abs(self.y[i] - self.avgFilter[i - 1]) > (self.threshold * self.stdFilter[i - 1]):

            if self.y[i] > self.avgFilter[i - 1]:
                self.signals[i] = 1
            else:
                self.signals[i] = -1

            self.filteredY[i] = self.influence * self.y[i] + \
                (1 - self.influence) * self.filteredY[i - 1]
            self.avgFilter[i] = np.mean(self.filteredY[(i - self.lag):i])
            self.stdFilter[i] = np.std(self.filteredY[(i - self.lag):i])
        else:
            self.signals[i] = 0
            self.filteredY[i] = self.y[i]
            self.avgFilter[i] = np.mean(self.filteredY[(i - self.lag):i])
            self.stdFilter[i] = np.std(self.filteredY[(i - self.lag):i])

        return self.signals[i]


def peakFind(df: pd.DataFrame, comparator: callable, exclude: list[str] = None, **kwargs) -> pd.Series:
    """Finds the indexes of relative peaks in the analog signal after being added together using scipy's argrelextrema

    Args:
        df (pd.DataFrame): The dataframe to find the relative peaks on
        comparator (callable): The comparator to use
        exclude (list[str], optional): The columns to not include in the sum. Defaults to None.

    Returns:
        np.ndarray: A numpy array that contains the index of the relative maximums
    """
    if exclude is None:
        exclude = list(_TIME_COLS.keys())
    includeCols = df.columns.difference(exclude)
    totals: pd.Series = df.loc[:, includeCols].sum(axis=1)
    peakIdx = argrelextrema(totals.values, comparator, **kwargs)[0]
    peakIdx = np.argsort(totals.iloc[peakIdx]) #Sorts the indexes
    return peakIdx