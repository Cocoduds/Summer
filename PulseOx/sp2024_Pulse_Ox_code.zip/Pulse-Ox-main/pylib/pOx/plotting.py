import matplotlib.pyplot as plt
import matplotlib.dates as md
import pandas as pd
import itertools

from math import factorial
from dataclasses import dataclass, asdict
from typing import Union, Callable, Dict
from datetime import timedelta

@dataclass
class spectBandDC:
    waveLengthnm: str
    color: Union[tuple[float, float, float], str]

    @property
    def label(self) -> str:
            return f"{self.waveLengthnm} nm"
        
@dataclass
class customLblBandDC:
    label: str
    color: Union[tuple[float, float, float], str]


class pltDateForm:
    def __enter__(self, fig: plt.Figure, ax: list[plt.Axes], dateForm: str, **kwargs):
        self.dateForm = md.DateFormatter(dateForm, **kwargs)
        self.ax = ax
        self.fig = fig

    def __exit__(self, *exc):
        for ax in self.ax:
            ax.xaxis.set_major_formatter(self.dateForm)
        self.fig.autofmt_xdate()
        return False

colData: Dict[str, Union[spectBandDC, customLblBandDC]] = {
    "F1": spectBandDC(415, (118/255.0, 0/255.0, 237/255.0)),
    "F2": spectBandDC(445, color=(0/255.0, 40/255.0, 255/255.0)),
    "F3": spectBandDC(480, color=(0/255.0, 213/255.0, 255/255.0)),
    "F4": spectBandDC(515, color=(31/255.0, 255/255.0, 0/255.0)),
    "F5": spectBandDC(555, color=(179/255.0, 255/255.0, 0/255.0)),
    "F6": spectBandDC(590, color=(255/255.0, 223/255.0, 0/255.0)),
    "F7": spectBandDC(630, color=(255/255.0, 79/255.0, 0/255.0)),
    "F8": spectBandDC(680, color=(223/255.0, 0/255.0, 0/255.0)),
    "NIR": spectBandDC(910, color=(98/255.0, 0/255.0, 0/255.0)),
    "CLEAR": spectBandDC(415, color="violet"),
    "FLICKER": spectBandDC(415, color="violet"),
    "total": customLblBandDC(label="sum", color="black")
}

def batch(iterable, n:int=1, size: int = None):
    l = 0
    if size is None:
        l = len(iterable)
    else:
        l = size
    
    for ndx in range(0, l, n):
        yield itertools.islice(iterable, ndx, min(ndx + n, l))

def plotTimeHist(data: pd.Series, transform: callable = None, **kwargs):
    diff = data.diff().fillna(timedelta(milliseconds=200))
    diff = diff.dt.total_seconds()
    if transform is not None:
        diff = diff.apply(transform)
    diff.plot.hist(**kwargs)

def plotRatio(data: pd.DataFrame, cols: list[str], ax: Union[plt.Axes, list[plt.Axes]] = None, scaled: bool = True, kwargFun: Callable[[str, str], dict] = None):
    if kwargFun is None:
        kwargFun = lambda x, y: {'label': f"{x} / {y}"}

    axs = None
    axBatch = None
    if ax is None:
        axs = [plt.gca()]
        axBatch = 1
    elif isinstance(ax, plt.Axes):
        axBatch = 1
        axs = [ax]
    else:
        axBatch = len(ax)
        axs = ax

    selection = data[cols]
    if scaled:
        selection = selection / selection.max()

    permSize = factorial(len(cols)) // 2
    ratioIter = zip(axs, batch(itertools.combinations(selection.items(), r=2), permSize // axBatch, permSize))
    for ax, calsIter in ratioIter:
        for (numColName, numSeries), (denColName, denSeries) in calsIter:
            lineData: pd.Series = numSeries / denSeries
            lineData.plot.line(ax=ax, **kwargFun(numColName, denColName))
    return axs