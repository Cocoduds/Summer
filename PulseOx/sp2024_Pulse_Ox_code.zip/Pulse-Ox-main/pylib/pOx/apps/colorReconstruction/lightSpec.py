import tkinter as tk
from tkinter import ttk

import pandas as pd
import json
import os.path as osp
from pOx.plotting import colData

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.pyplot import Axes, Line2D

from typing import Union, Callable

bgLoc = "./data/raw/Color_reconstruction/backgrounds"
dataLoc = "./data/raw/Color_reconstruction/datafiles"

class plotFrame(tk.Frame):
    def __init__(self, root: tk.Frame, 
                 bgLoc: str, 
                 dataLoc: str, 
                 metaLoc: str,
                 expLoc: str, 
                 dispFun: Callable[[pd.DataFrame], pd.DataFrame], 
                 **fkwargs):
        super().__init__(root, **fkwargs)
        self.exp = pd.read_csv(expLoc, skipinitialspace=True)
        self.bgLoc = bgLoc
        self.dataLoc = dataLoc
        self.dispFun = dispFun

        with open(metaLoc, 'r') as f:
            self.meta = json.load(f)

        self.fig = Figure((6, 4), dpi=100)
        self.ax = self.fig.add_subplot()

        self.canvas = FigureCanvasTkAgg(self.fig, self)
        self.canvas.draw()
        self.toolbar = NavigationToolbar2Tk(self.canvas, self, pack_toolbar=False)
        self.toolbar.update()

        self.canvas.get_tk_widget().grid(column=0, row=0, sticky='nsew')
        self.toolbar.grid(column=0, row=1, sticky='nsew')

        self.plotFile(0)

    def _readBG(self, name: str) -> pd.DataFrame:
        bgLoc = osp.join(self.bgLoc, f"{name}.csv")

        bgData = pd.read_csv(bgLoc)
        bgData = self.dispFun(bgData)
        return bgData.sort_values(by=bgData.columns[0])

    def _readData(self, name: str) -> pd.DataFrame:
        dataLoc = osp.join(self.dataLoc, f"{name}")

        data = pd.read_csv(dataLoc)
        return data
    
    def _clear(self):
        while len(self.ax.patches) != 0:
            self.ax.patches[0].remove()

        while len(self.ax.lines) != 0:
            self.ax.lines[0].remove()
        self.ax.set_prop_cycle(None)

    def selectFile(self, name: Union[str, int]):
        if isinstance(name, int):
            row = self.exp.iloc[name, :]
        else:
            row = self.exp[self.exp['fname'] == name]
            row = row.iloc[0, :]

        backgrounds = self.meta['lightData'][str(row['lightID'])]['bg']
        self._clear()

        for fname in backgrounds:
            bg = self._readBG(fname)
            self.ax.plot(bg.iloc[:, 0], bg.iloc[:, 1], label=fname)

        data = self._readData(row['fname'])
        dataClip = data[(data['MTIME'] > row['lowT']) & (data['MTIME'] < row['highT'])]
        meanSet = dataClip[[f"F{x}" for x in range(1, 11)]].mean()
        meanSet = 100* meanSet / meanSet.max()

        for i in range(1, 10):
            refName = f"F{i}"
            colName = f"F{i}"
            if i == 9:
                refName = "NIR"

            self.ax.bar(colData[refName].waveLengthnm, meanSet[colName], 
                width=10,
                color=colData[refName].color,
                label=f'{colData[refName].label} ({refName})')

    def plotFile(self, name: Union[str, int]):
        self.selectFile(name)
        self.canvas.draw()


if __name__ == "__main__":
    root = tk.Tk()
    comboState = tk.StringVar(root)

    plot = plotFrame(root, bgLoc, dataLoc, 
                     "./data/raw/Color_reconstruction/metaData.json",
                     "./data/raw/Color_reconstruction/experiments.csv",
                     lambda x: x)
    combo = ttk.Combobox(root, width=30, textvariable=comboState)
    combo['values'] = tuple(plot.exp.iloc[:, 0])
    combo.bind("<<ComboboxSelected>>", lambda _: plot.plotFile(combo.get()))
    

    plot.grid(column=0, row=0)
    combo.grid(column=1, row=0)
    root.mainloop()
