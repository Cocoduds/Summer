import tkinter as tk
from tkinter import ttk

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.pyplot import Axes

import numpy as np

from dataclasses import dataclass

def testFun(domain: np.ndarray, phi: float, freq: float):
    return 2 * np.sin(2 * np.pi * freq * domain + phi)

def testFun2(domain: np.ndarray, phi: float, freq: float):
    return 2 * np.cos(2 * np.pi * freq * domain + phi)

@dataclass
class config:
    phase: float
    freq: float

if __name__ == "__main__":
    root = tk.Tk()
    root.wm_title("Embedding setup in Tk")
    notebook = ttk.Notebook(root)

    state = config(0, 1)

    fig = Figure(figsize=(5, 4), dpi=100)
    domain = np.arange(0, 5, 0.01)
    ax = fig.add_subplot()
    line, = ax.plot(domain, testFun(domain, state.phase, state.freq))
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("F(t)")

    fig2 = Figure(figsize=(5, 4), dpi=100)
    ax2 = fig2.add_subplot()
    line2, = ax2.plot(domain, testFun2(domain, state.phase, state.freq))
    ax2.set_xlabel("Time [s]")
    ax2.set_ylabel("F(t)")

    page1 = tk.Frame(notebook)
    page2 = tk.Frame(notebook)

    notebook.add(page1, text="Graph 1")
    notebook.add(page2, text="Graph 2")

    tkPlot = FigureCanvasTkAgg(fig, page1)
    tkPlot2 = FigureCanvasTkAgg(fig2, page2)
    tkPlot.draw()
    tkPlot2.draw()

    toolbar = NavigationToolbar2Tk(tkPlot, page1, pack_toolbar=False)
    toolbar2 = NavigationToolbar2Tk(tkPlot2, page2, pack_toolbar=False)
    toolbar.update()

    sliders = tk.Frame(root)

    def update_freq(newVal):
        f = float(newVal)
        state.freq = f

        line.set_data(domain, testFun(domain, state.phase, state.freq))
        line2.set_data(domain, testFun2(domain, state.phase, state.freq))
        tkPlot.draw()
        tkPlot2.draw()

    def update_phase(newVal):
        phi = float(newVal)
        state.phase = phi

        line.set_data(domain, testFun(domain, state.phase, state.freq))
        line2.set_data(domain, testFun2(domain, state.phase, state.freq))
        tkPlot.draw()
        tkPlot2.draw()

    freqSlider = tk.Scale(sliders, from_=0, to=10, orient=tk.HORIZONTAL, resolution=0.5, tickinterval=5,
                            command=update_freq, label="Frequency [Hz]")
    phaseSlider = tk.Scale(sliders, from_=1, to=5, orient=tk.HORIZONTAL, resolution=0.5, tickinterval=1,
                            command=update_phase, label="Phase")
    
    notebook.grid(column=0, row=0, sticky='nsew')
    sliders.grid(column=0, row=1)
    tkPlot.get_tk_widget().grid(column=0, row=0)
    tkPlot2.get_tk_widget().grid(column=0, row=0)
    toolbar.grid(column=0, row=1)
    toolbar2.grid(column=0, row=1)

    freqSlider.grid(column=0, row=0)
    phaseSlider.grid(column=0, row=1)

    root.columnconfigure(0, weight=2)
    root.columnconfigure(1, weight=1)

    root.mainloop()