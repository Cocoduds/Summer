import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
import pOx

import os

dataLoc = "./data/raw/calibration/exp2/exp{id}.csv"
metaLoc = "./data/raw/calibration/metaData.csv"
commercial = "./data/raw/calibration/exp2/POx_Commercial.csv"
readIdx = 24
dispCol = 'ADC6'
initThresh = 1.10
initLag = 50

class peakPlotStateMachine:
    def __init__(self, df: pd.DataFrame, ax: plt.Axes, dispCol: str, initLag: int, initThreshold: float) -> None:
        self.df = df
        self.ax = ax
        self.dispCol = dispCol
        self.lag = initLag
        self.thres = initThreshold
        self.first = True

        self.currMap = {
            "ADC1": "F8",
            "ADC2": "F7",
            "ADC3": "F6",
            "ADC4": "F5",
            "ADC5": "F4",
            "ADC6": "NIR"
        }

    @property
    def wavelength(self):
        lbl = self.currMap.get(self.dispCol, 'UNK')
        if lbl != 'UNK':
            return pOx.plotting.colData[lbl].label
        else:
            return 'UNK'

    def setLag(self, newLag: float):
        self.lag = int(newLag)
        self.plotData()

    def setThreshold(self, newThresh: float):
        self.thres = newThresh
        self.plotData()

    def plotData(self):
        finder = pOx.peaks.windowPeaks(self.lag, self.thres)
        for val in self.df['sum']:
            finder.addData(val)

        highTimes = self.df['MTIME'][finder.signals == 1]
        lowTimes = self.df['MTIME'][finder.signals == -1]
        highVals = self.df[self.dispCol][finder.signals == 1]
        lowVals = self.df[self.dispCol][finder.signals == -1]

        if not self.first:
            currXLims = self.ax.get_xlim()
            currYLims = self.ax.get_ylim()

        self.ax.cla()
        self.df.plot('MTIME', self.dispCol, ax=self.ax, legend=False, label=self.wavelength)
        self.ax.plot(highTimes, highVals, linestyle='', marker='.', label='Peaks')
        self.ax.plot(lowTimes, lowVals, linestyle='', marker='.', label='Valleys')
        # self.ax.plot(self.df['MTIME'][self.lag:], finder._avgs[self.lag:], label='Avg')
        # self.ax.plot(self.df['MTIME'][self.lag:], self.df[self.dispCol][self.lag:])

        self.ax.legend()
        self.ax.set_ylabel(f"Channel Count for {self.wavelength}")
        self.ax.set_xlabel("Milliseconds since device started")
        
        if not self.first:
            self.ax.set_xlim(*currXLims)
            self.ax.set_ylim(*currYLims)

        if self.first: self.first = False

metaDf = pd.read_csv(metaLoc, index_col=0)
df = pd.read_csv(dataLoc.format(id=readIdx))
df = df[(df['MTIME'] > metaDf.loc[readIdx].iloc[1]) & (df['MTIME'] < metaDf.loc[readIdx].iloc[2])]

df['sum'] = df[[f'ADC{x}' for x in range(1, 7)]].sum(axis=1)


ax: plt.Axes
fig, ax = plt.subplots(1, 1)

state = peakPlotStateMachine(df, ax, dispCol, initLag, initThresh)

fig.subplots_adjust(bottom=0.25)

axlag = fig.add_axes([0.1, 0.1, 0.75, 0.03])
lagSlider = Slider(
    axlag,
    "Lag",
    valmin=1,
    valmax=60,
    valstep=1,
    valinit=initLag,
    dragging=True
)
lagSlider.on_changed(state.setLag)

axThresh = fig.add_axes([0.15, 0.125, 0.65, 0.03])
threshSlider = Slider(
    axThresh,
    'Threshold',
    valmin=0.25,
    valmax=3,
    valstep=0.05,
    valinit=initThresh,
    dragging=True
)
threshSlider.on_changed(state.setThreshold)

state.plotData()
plt.show(block=True)