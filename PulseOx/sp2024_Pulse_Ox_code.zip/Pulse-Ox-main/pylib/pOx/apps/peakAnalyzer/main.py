import tkinter as tk
from tkinter import ttk

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.pyplot import Axes

from typing import Callable
import os.path as osp

import numpy as np
import pandas as pd
import pOx

class zScorePeakState:
    def __init__(self, df: pd.DataFrame, col: str, initLag: int, initThreshold: float) -> None:
        self.df = df
        self.col = col
        self.lag = initLag
        self.threshold = initThreshold
        self.finder = pOx.peaks.windowPeaks(self.lag, self.threshold)

        self.currMap = {
            "ADC1": "F8",
            "ADC2": "F7",
            "ADC3": "F6",
            "ADC4": "F5",
            "ADC5": "F4",
            "ADC6": "NIR"
        }
        self._setupFinder()

    def genLbl(self, col: str) -> str:
        lbl = self.currMap.get(col, 'UNK')
        if lbl == 'UNK':
            return lbl
        
        return pOx.colData[lbl].label
    
    def _setupFinder(self) -> pOx.peaks.windowPeaks:
        self.finder.clear()
        for val in self.df[self.col]:
            self.finder.addData(val)
        return self.finder

    def setThreshold(self, newThresh: float) -> pOx.peaks.windowPeaks:
        self.threshold = newThresh
        self.finder.threshold = newThresh
        return self._setupFinder()

    def setLag(self, newLag: int) -> pOx.peaks.windowPeaks:
        if not isinstance(newLag, int):
            newLag = int(newLag)
        self.lag = newLag
        self.finder.lag = newLag
        return self._setupFinder()
    
    def setDf(self, df: pd.DataFrame) -> pOx.peaks.windowPeaks:
        self.df = df
        return self._setupFinder()
    
    def setCol(self, col: str) -> pOx.peaks.windowPeaks:
        self.col = col
        return self._setupFinder()
    
class pagePlot(tk.Frame):
    def __init__(self, root: tk.Frame, fun: Callable[[Axes, pd.DataFrame, zScorePeakState], None]):
        super().__init__(root)
        self.fun = fun
        self.fig = Figure((5, 4), dpi=100)
        self.ax = self.fig.add_subplot()
        
        self.plot = FigureCanvasTkAgg(self.fig, self)
        self.plot.draw()
        self.toolbar = NavigationToolbar2Tk(self.plot, self, pack_toolbar=False)
        self.toolbar.update()

        self.plot.get_tk_widget().grid(column=0, row=0, sticky='nsew')
        self.toolbar.grid(column=0, row=1, sticky='nsew')
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=9)
        self.rowconfigure(1, weight=1)

    def update(self, df: pd.DataFrame, state: zScorePeakState):
        self.fun(self.ax, df, state)
        self.ax.relim()
        self.plot.draw()
        
class plottingNotebook(tk.Frame):
    def __init__(self, root: tk.Frame, state: zScorePeakState,
                 funs: dict[str, Callable[[Axes, pd.DataFrame, zScorePeakState], None]]
                ):
        super().__init__(root)
        self.state = state
        self.funs = funs
        self.graphs: dict[str, pagePlot] = {}
        self.notebook = ttk.Notebook(self)

        for name, fun in self.funs.items():
            self.graphs[name] = pagePlot(self.notebook, fun)
            self.notebook.add(self.graphs[name], text=name)

        self.notebook.grid(column=0, row=0, sticky='nsew')
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

    def update(self, df: pd.DataFrame):
        for _, plot in self.graphs.items():
            plot.update(df, self.state)

    def relim(self):
        for _, plot in self.graphs.items():
            plot.ax.relim()

def setLineCount(ax: Axes, count: int):
    if len(ax.get_lines()) == count:
        return
    
    while len(ax.get_lines()) < count:
        ax.plot([], [])

    while len(ax.get_lines()) > count:
        ax.remove(ax.get_lines()[0])

class peakPlotter:
    def __init__(self, state: zScorePeakState) -> None:
        self.state = state
        self.highTimes = pd.Series()
        self.highVals = pd.Series()
        self.lowTimes = pd.Series()
        self.lowVals = pd.Series()
        self.maxes = np.array([])
        self.ratioDf = pd.DataFrame()

    def calcMaxes(self):
        self.highTimes = self.state.df['MTIME'][self.state.finder.signals == 1]
        self.highVals = self.state.df[self.state.col][self.state.finder.signals == 1]
        self.lowTimes = self.state.df['MTIME'][self.state.finder.signals == -1]
        self.lowVals = self.state.df[self.state.col][self.state.finder.signals == -1]

        zeroFiltIdx = np.argwhere(self.state.finder.signals != 0).flatten() #Creating a filter for where there is a signal
        diffs = np.diff(self.state.finder.signals[zeroFiltIdx]) #Finding where the signal type changes
        idx = np.argwhere(diffs != 0).flatten() #Getting the index of where the change occurs
        groups = np.split(zeroFiltIdx, idx + 1) #Splitting the indexes by peak type

        self.maxes = []
        for group in groups:
            self.maxes.append(max(group, key=self.state.finder.data.__getitem__))

        self.ratioDf['MTIME'] = self.state.df['MTIME'].iloc[self.maxes][1:len(df['MTIME'].iloc[self.maxes]):2]
        for col in [f"ADC{x}" for x in range(1, 7)]:
            colLen = len(self.state.df[col].iloc[self.maxes])
            self.ratioDf[col] = np.abs(np.diff(self.state.df[col].iloc[self.maxes])[::2] / self.state.df[col].iloc[self.maxes][1:colLen:2])
    
    def plotExtremas(self, ax: Axes, df: pd.DataFrame, state: zScorePeakState):
        if len(ax.get_lines()) != 4:
            setLineCount(ax, 4)
            ax.get_lines()[0].set(label=state.col)
            ax.get_lines()[1].set(linestyle='', marker='.', label='Peaks')
            ax.get_lines()[2].set(linestyle='', marker='.', label='Valleys')
            ax.get_lines()[3].set(color='red', linestyle='', marker='o', label='Absolute Extrema')

        ax.get_lines()[0].set_data(df['MTIME'], df[state.col])
        ax.get_lines()[1].set_data(self.highTimes, self.highVals)
        ax.get_lines()[2].set_data(self.lowTimes, self.lowVals)
        ax.get_lines()[3].set_data(df['MTIME'].iloc[self.maxes], df[state.col].iloc[self.maxes])

        # for i in range(4):
        #     ax.get_lines()[i].recache()
        ax.legend()
        return None

    def plotModulation(self, ax: Axes, df: pd.DataFrame, state: zScorePeakState):
        if len(ax.get_lines()) != 6:
            setLineCount(ax, 6)
            for i in range(1, 7):
                col = f"ADC{i}"
                ax.get_lines()[i-1].set(marker = '.', label=col)

        self.ratioDf['MTIME'] = df['MTIME'].iloc[self.maxes][1:len(df['MTIME'].iloc[self.maxes]):2]
        for col in [f"ADC{x}" for x in range(1, 7)]:
            colLen = len(df[col].iloc[self.maxes])
            self.ratioDf[col] = np.abs(np.diff(df[col].iloc[self.maxes])[::2] / df[col].iloc[self.maxes][1:colLen:2])

        for i in range(6):
            col = f"ADC{i+1}"
            ax.get_lines()[i].set_data(self.ratioDf['MTIME'], self.ratioDf[col])
        ax.legend()
        return None

    def plotBetas(self, ax: Axes, df: pd.DataFrame, state: zScorePeakState):
        if len(ax.get_lines()) != 5:
            setLineCount(ax, 5)
            for i in range(1, 6):
                col = f"ADC{i} / NIR"
                ax.get_lines()[i-1].set(marker = '.', label=col)

        for i in range(5):
            col = f"ADC{i+1}"
            yVal = self.ratioDf[col] / self.ratioDf['ADC6']
            yVal = np.clip(yVal, 0, 10)
            ax.get_lines()[i].set_data(self.ratioDf['MTIME'], yVal)
        ax.legend()
        return None


def plotExtremas(ax: Axes, df: pd.DataFrame, state: zScorePeakState):
    if len(ax.get_lines()) != 4:
        setLineCount(ax, 4)
        ax.get_lines()[0].set(label=state.col)
        ax.get_lines()[1].set(linestyle='', marker='.', label='Peaks')
        ax.get_lines()[2].set(linestyle='', marker='.', label='Valleys')
        ax.get_lines()[3].set(color='red', linestyle='', marker='o', label='Absolute Extrema')
    highTimes = df['MTIME'][state.finder.signals == 1]
    highVals = df[state.col][state.finder.signals == 1]
    lowTimes = df['MTIME'][state.finder.signals == -1]
    lowVals = df[state.col][state.finder.signals == -1]

    zeroFiltIdx = np.argwhere(state.finder.signals != 0).flatten() #Creating a filter for where there is a signal
    diffs = np.diff(state.finder.signals[zeroFiltIdx]) #Finding where the signal type changes
    idx = np.argwhere(diffs != 0).flatten() #Getting the index of where the change occurs
    groups = np.split(zeroFiltIdx, idx + 1) #Splitting the indexes by peak type

    maxes = []
    for group in groups:
        maxes.append(max(group, key=state.finder.data.__getitem__))

    ax.get_lines()[0].set_data(df['MTIME'], df[state.col])
    ax.get_lines()[1].set_data(highTimes, highVals)
    ax.get_lines()[2].set_data(lowTimes, lowVals)
    ax.get_lines()[3].set_data(df['MTIME'].iloc[maxes], df[state.col].iloc[maxes])

    # for i in range(4):
    #     ax.get_lines()[i].recache()
    ax.legend()
    return None

def plotModulation(ax: Axes, df: pd.DataFrame, state: zScorePeakState):
    if len(ax.get_lines()) != 6:
        setLineCount(ax, 6)
        for i in range(1, 7):
            col = f"ADC{i}"
            ax.get_lines()[i-1].set(marker = '.', label=col)

    rDf = pd.DataFrame()
    zeroFiltIdx = np.argwhere(state.finder.signals != 0).flatten() #Creating a filter for where there is a signal
    diffs = np.diff(state.finder.signals[zeroFiltIdx]) #Finding where the signal type changes
    idx = np.argwhere(diffs != 0).flatten() #Getting the index of where the change occurs
    groups = np.split(zeroFiltIdx, idx + 1) #Splitting the indexes by peak type

    maxes = []
    for group in groups:
        maxes.append(max(group, key=state.finder.data.__getitem__))

    rDf['MTIME'] = df['MTIME'].iloc[maxes][1:len(df['MTIME'].iloc[maxes]):2]
    for col in [f"ADC{x}" for x in range(1, 7)]:
        colLen = len(df[col].iloc[maxes])
        rDf[col] = np.abs(np.diff(df[col].iloc[maxes])[::2] / df[col].iloc[maxes][1:colLen:2])

    for i in range(6):
        col = f"ADC{i+1}"
        ax.get_lines()[i].set_data(rDf['MTIME'], rDf[col])
    ax.legend()
    return None
    
def plotBetas(ax: Axes, df: pd.DataFrame, state: zScorePeakState):
    if len(ax.get_lines()) != 5:
        setLineCount(ax, 5)
        for i in range(1, 6):
            col = f"ADC{i} / NIR"
            ax.get_lines()[i-1].set(marker = '.', label=col)

    rDf = pd.DataFrame()
    zeroFiltIdx = np.argwhere(state.finder.signals != 0).flatten() #Creating a filter for where there is a signal
    diffs = np.diff(state.finder.signals[zeroFiltIdx]) #Finding where the signal type changes
    idx = np.argwhere(diffs != 0).flatten() #Getting the index of where the change occurs
    groups = np.split(zeroFiltIdx, idx + 1) #Splitting the indexes by peak type

    maxes = []
    for group in groups:
        maxes.append(max(group, key=state.finder.data.__getitem__))

    rDf['MTIME'] = df['MTIME'].iloc[maxes][1:len(df['MTIME'].iloc[maxes]):2]
    for col in [f"ADC{x}" for x in range(1, 7)]:
        colLen = len(df[col].iloc[maxes])
        rDf[col] = np.abs(np.diff(df[col].iloc[maxes])[::2] / df[col].iloc[maxes][1:colLen:2])

    for i in range(5):
        col = f"ADC{i+1}"
        yVal = rDf[col] / rDf['ADC6']
        yVal = np.clip(yVal, 0, 10)
        ax.get_lines()[i].set_data(rDf['MTIME'], yVal)
    ax.legend()
    return None

def buildUpdater(notebook: plottingNotebook, fnName: str):
    setFunction = getattr(notebook.state, fnName)
    def update(newVal: str):
        f = float(newVal)
        setFunction(f)
        notebook.update(notebook.state.df)
    return update

if __name__ == "__main__":
    baseLoc = "./data/raw/calibration"
    experimentLoc = osp.join(baseLoc, "exp2/exp{}.csv")
    metaLoc = osp.join(baseLoc, "metaData.csv")
    readIdx = 19

    metaDf = pd.read_csv(metaLoc, index_col=0)
    df = pd.read_csv(experimentLoc.format(readIdx))
    df = df[(df['MTIME'] > metaDf.loc[readIdx].iloc[1]) & (df['MTIME'] < metaDf.loc[readIdx].iloc[2])]
    df['sum'] = df[[f'ADC{x}' for x in range(1, 7)]].sum(axis=1)
    state = zScorePeakState(df, 'sum', 50, 1.10)

    root = tk.Tk()
    nb = plottingNotebook(root, state, {
        "Peaks": plotExtremas,
        "Modulation": plotModulation,
        "Betas": plotBetas
    })
    nb.update(df)
    configFrame = tk.Frame(root)

    threshSlider = tk.Scale(configFrame, from_=0, to=2,orient=tk.HORIZONTAL, resolution=0.01,
                            tickinterval=0.5, command=buildUpdater(nb, 'setThreshold'),
                            label='Threshold')
    lagSlider = tk.Scale(configFrame, from_=0, to=60, orient=tk.HORIZONTAL, resolution=1,
                            tickinterval=10, command=buildUpdater(nb, 'setLag'),
                            label='Lag')
    

    threshSlider.grid(column=0, row=0, sticky='ew')
    lagSlider.grid(column=0, row=1, sticky='ew')
    configFrame.grid(column=1, row=0, sticky='nsew')
    nb.grid(column=0, row=0, sticky='nsew')

    configFrame.columnconfigure(0, weight=1)
    configFrame.rowconfigure(0, weight=1)
    configFrame.rowconfigure(1, weight=1)
    root.columnconfigure(0, weight=8)
    root.columnconfigure(1, weight=2)
    root.rowconfigure(0, weight=1)

    root.mainloop()