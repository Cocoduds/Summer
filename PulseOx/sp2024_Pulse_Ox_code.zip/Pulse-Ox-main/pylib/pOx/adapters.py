from datetime import timedelta
import pandas as pd
from dataclasses import dataclass, asdict

@dataclass
class timeColDC:
    units: str
    cumulative: bool = False

_TIME_COLS: dict[str, timeColDC] = {
    "TIME_UTX": timeColDC("s"),
    "MTIME": timeColDC("ms", True)
}

def calcTime(df: pd.DataFrame, cumulativeCol: str) -> pd.DataFrame:
    df = df.copy()
    df[cumulativeCol] = pd.to_datetime(0)
    for col in df.columns:
        if col not in _TIME_COLS:
            continue
        details = _TIME_COLS[col]
        df[col] = pd.to_datetime(df[col], unit=details.units)
        df[col] = df[col] - df[col][0]

        if details.cumulative:
            df[col] = df[col] - df[col].dt.floor('s')
        df[cumulativeCol] += df[col]
    return df

def readData(path: str, cumulativeCol: str = "Time", timeCols: list[str] = None, drop: bool = True, setIdx: bool = True) -> pd.DataFrame:
    if timeCols is None:
        timeCols = list(_TIME_COLS.keys())
    df = pd.read_csv(path, index_col=False)
    if cumulativeCol in df:
        raise ValueError("The name of the cumulative column cannot already be in the dataframe")

    filteredTime = [x for x in timeCols if x in df.columns and x in _TIME_COLS]

    df[filteredTime + [cumulativeCol]] = calcTime(
        df[filteredTime],
        cumulativeCol
    )

    if drop:
        df = df.drop(columns=_TIME_COLS)
    rollOverIdx = df[cumulativeCol].diff().fillna(timedelta(0)) > timedelta(seconds=1)
    df.loc[rollOverIdx, cumulativeCol] = df[cumulativeCol][rollOverIdx].dt.floor('s')

    if setIdx:
        df = df.set_index(cumulativeCol)
    return df
            

