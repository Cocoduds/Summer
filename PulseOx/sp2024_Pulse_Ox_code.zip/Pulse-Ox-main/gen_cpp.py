import os
import atexit
from typing import List

Import("env")

def findFiles(dir: str) -> List[str]:
    files = env.Glob(f"{dir}/**/*.ino")
    # print(files)
    return files

def createCPP(file: str):
    newFname = file.replace(".ino", ".cpp")
    cmd = f"cp {file} {newFname}"
    print(cmd)
    os.system(f"cp {file} {newFname}")
    return newFname

def _delete_lnk(path: str):
    try:
        if os.path.isfile(path):
            os.remove(path)
    except:  # pylint: disable=bare-except
        pass

# for key in env.keys():
#     print(f"{key}: {env.subst('$' + key)}")
# print(env.keys())
libs = [x for x in env.subst("$LIBSOURCE_DIRS").split(" ") if ('.pio' not in x) and ('.platformio' not in x)]
for lib in libs:
    for file in findFiles(lib):
        # print(file)
        nFname = createCPP(file.get_abspath())
        atexit.register(_delete_lnk, nFname)
# with open(os.path.join(env.subst_path("$PROJECT_SRC_DIR")[0], "test.txt"), "w") as f:
#     f.write("test")
# atexit.register(_delete_lnk, )
